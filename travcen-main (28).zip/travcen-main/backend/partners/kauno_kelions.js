module.exports = async function gautiKaunoKelionesPasiulymus() {
  return [
    {
      title: "Kelionė į Barseloną",
      from: "Kaunas",
      to: "Barselona",
      type: "poilsis", // arba "pramogos", "kultūra" ir pan.
      price: 349,
      url: "https://kaunokeliones.lt/pasiulymai/barselona",
      image: "https://source.unsplash.com/280x180/?barcelona",
      partner: "Kauno Kelionės" // pridedame partnerio pavadinimą
    }
  ];
};
